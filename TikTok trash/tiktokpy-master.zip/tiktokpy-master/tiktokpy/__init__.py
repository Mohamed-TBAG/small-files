from .bot import TikTokPy

__all__ = ["TikTokPy"]
