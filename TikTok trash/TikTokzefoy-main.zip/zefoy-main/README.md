unpatched
> - added manual solving + cloudflare fix    
> - unstable    
> - need to put your own sessid sometimes   
> - you can find your cloudflare cookies and sessid on zefoy.com under the cookies tab   

#### Demo (outdated)

https://user-images.githubusercontent.com/98614666/200188523-f90b752d-dbe6-443a-9a84-61961a3489a1.mp4
