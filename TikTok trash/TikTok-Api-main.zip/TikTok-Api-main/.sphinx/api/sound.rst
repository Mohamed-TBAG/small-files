TikTokApi.api.sound module
----------------------------

.. automodule:: TikTokApi.api.sound
   :members:
   :undoc-members:
   :show-inheritance:
