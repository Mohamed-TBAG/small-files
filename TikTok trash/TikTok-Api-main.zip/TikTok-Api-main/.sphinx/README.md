The docs for TikTokAPI

Run locally with: make serve

Build with: make html