from api import TikTok

print(TikTok(session_id = "3e5f47507a3da4915c68c72e359e263c").edit_bio(bio = "bio", user_id = 7198124813334990086))